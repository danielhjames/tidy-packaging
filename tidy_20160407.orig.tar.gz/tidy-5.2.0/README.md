# HTML Tidy with HTML5 support

All READMEs and related materials can be found in [README/][1].

For build instructions please see [README/README.md][2].

 [1]: https://github.com/htacg/tidy-html5/tree/master/README
 [2]: https://github.com/htacg/tidy-html5/blob/master/README/README.md
 